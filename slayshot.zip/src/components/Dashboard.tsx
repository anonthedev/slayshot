"use client";

import { Button } from "./ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Loader2,
  Youtube,
  FileVideo,
  Clock,
  AlertCircle,
  Check,
  X,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import YouTubeVideoModal from "./YouTubeVideoModal";

import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

export default function Dashboard({
  uploadedFiles,
}: {
  uploadedFiles: {
    id: string;
    s3Key: string;
    filename: string;
    thumbnail?: string | null;
    status: string;
    clipsCount: number;
    createdAt: Date;
  }[];
}) {
  // const [files, setFiles] = useState<File[]>([]);
  // const [uploading, setUploading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [isYouTubeModalOpen, setIsYouTubeModalOpen] = useState(false);
  // const fileInputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const handleRefresh = async () => {
    setRefreshing(true);
    router.refresh();
    setTimeout(() => setRefreshing(false), 600);
  };

  // const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   const selectedFiles = event.target.files;
  //   if (selectedFiles && selectedFiles.length > 0) {
  //     setFiles(Array.from(selectedFiles));
  //   }
  // };

  // const handleFileButtonClick = () => {
  //   fileInputRef.current?.click();
  // };

  // const handleUpload = async () => {
  //   if (files.length === 0) return;

  //   const file = files[0]!;
  //   setUploading(true);

  //   try {
  //     const { success, signedUrl, uploadedFileId } = await generateUploadUrl({
  //       filename: file.name,
  //       contentType: file.type,
  //     });

  //     if (!success) throw new Error("Failed to get upload URL");

  //     const uploadResponse = await fetch(signedUrl, {
  //       method: "PUT",
  //       body: file,
  //       headers: {
  //         "Content-Type": file.type,
  //       },
  //     });

  //     if (!uploadResponse.ok)
  //       throw new Error(`Upload filed with status: ${uploadResponse.status}`);

  //     const result = await processVideo(uploadedFileId);
  //     console.log("Process result:", result);

  //     setFiles([]);

  //     toast.success("Video uploaded successfully", {
  //       description:
  //         "Your video has been scheduled for processing. Check the status below.",
  //       duration: 5000,
  //     });
  //   } catch (error) {
  //     console.error("Upload failed:", error);
  //     toast.error("Upload failed", {
  //       description:
  //         "There was a problem uploading your video. Please try again.",
  //     });
  //   } finally {
  //     setUploading(false);
  //   }
  // };

  const handleYouTubeSubmit = () => {
    if (!youtubeUrl.trim()) {
      toast.error("Please enter a YouTube URL");
      return;
    }

    // Improved validation for all YouTube URL formats
    const youtubeRegex = /^(https?:\/\/)?((www|m)\.)?(youtube\.com\/(watch\?v=|embed\/|v\/|shorts\/)|youtu\.be\/)[a-zA-Z0-9_-]{11}/;
    if (!youtubeRegex.test(youtubeUrl)) {
      toast.error("Please enter a valid YouTube URL");
      return;
    }

    setIsYouTubeModalOpen(true);
  };

  const handleCloseYouTubeModal = () => {
    setIsYouTubeModalOpen(false);
    setYoutubeUrl("");
    handleRefresh();
  };

  const handleRowClick = (item: { id: string; clipsCount: number; thumbnail?: string | null }) => {
    if (item.clipsCount > 0) {
      router.push(`/dashboard/clips/${item.id}`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "queued":
        return <Clock className="h-3 w-3" />;
      case "processing":
        return (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
            <span>Processing</span>
          </div>
        );
      case "processed":
        return <Check className="h-4 w-4" />;
      case "failed":
        return <X className="h-4 w-4" />;
      case "no credits":
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "processed":
        return "default";
      case "processing":
        return "secondary";
      case "failed":
      case "no credits":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "processed":
        return "text-green-600 bg-transparent";
      case "processing":
        return "text-blue-400 bg-transparent";
      case "failed":
        return "text-red-600 bg-transparent";
      case "no credits":
        return "text-red-600 bg-transparent";
      default:
        return "text-muted-foreground bg-transparent";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto flex max-w-6xl flex-col space-y-8 px-6 py-12">
        <div className="space-y-6">
          <Card className="border-2 border-dashed border-muted-foreground/25 bg-card/50">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl flex items-center justify-center gap-2">
                <Youtube className="h-6 w-6 text-red-500" />
                Process Video
              </CardTitle>
              <CardDescription className="text-base">
                Paste a YouTube URL or upload a video file to generate clips
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="youtube-url" className="text-sm font-medium">
                  YouTube URL or Upload File
                </Label>
                <div className="flex flex-row gap-3 items-center">
                  <Input
                    id="youtube-url"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    className="flex-1 text-base"
                  />
                  <Button
                    size="lg"
                    disabled={!youtubeUrl.trim()}
                    onClick={handleYouTubeSubmit}
                    className="px-8 gap-2"
                  >
                    <Youtube className="h-4 w-4" />
                    Get Details
                  </Button>
                </div>
              </div>
              {/* <Button
                variant="outline"
                size="icon"
                onClick={handleFileButtonClick}
                disabled={uploading}
                className=""
              >
                <Upload className="h-3 w-3" />
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4"
                onChange={handleFileSelect}
                className="hidden"
              />
              {files.length > 0 && (
                <div className="flex items-center justify-between pt-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileVideo className="h-4 w-4" />
                    <span>{files[0]?.name}</span>
                    <span>
                      ({(files[0]?.size / (1024 * 1024)).toFixed(1)} MB)
                    </span>
                  </div>
                  <Button
                    disabled={uploading}
                    onClick={handleUpload}
                    className="gap-2"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4" />
                        Generate Clips
                      </>
                    )}
                  </Button>
                </div>
              )} */}
            </CardContent>
          </Card>

          {uploadedFiles.length > 0 && (
            <Card>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Processing Queue</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRefresh}
                    disabled={refreshing}
                    className="gap-2 bg-transparent"
                  >
                    {refreshing && <Loader2 className="h-4 w-4 animate-spin" />}
                    Refresh
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {uploadedFiles.map((item) => (
                    <Card
                      key={item.id}
                      className={cn(
                        item.clipsCount > 0
                          ? "cursor-pointer hover:shadow-md transition-all duration-200 hover:scale-[1.02]"
                          : "transition-all duration-200", "py-0 my-0"
                      )}
                      onClick={() => handleRowClick(item)}
                    >
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Thumbnail */}
                          <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                            {item.thumbnail ? (
                              <img 
                                src={item.thumbnail} 
                                alt="Video thumbnail" 
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <FileVideo className="h-8 w-8 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          
                          {/* Title */}
                          <div>
                            <h4 className="font-medium text-sm line-clamp-2 leading-tight">
                              {item.filename}
                            </h4>
                          </div>
                          
                          {/* Status and Date */}
                          <div className="flex items-center justify-between">
                            {item.status === "processing" ? (
                              <Badge
                                className={cn("p-0 text-xs font-normal", getStatusStyle(item.status))}
                              >
                                {getStatusIcon(item.status)}
                              </Badge>
                            ) : (
                              <Badge
                                variant={getStatusVariant(item.status)}
                                className={cn("p-0 text-xs font-normal", getStatusStyle(item.status))}
                              >
                                {getStatusIcon(item.status)}
                                {item.status.charAt(0).toUpperCase() +
                                  item.status.slice(1)}
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">
                              {new Date(item.createdAt).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric',
                                hour: 'numeric',
                                minute: '2-digit',
                                hour12: true
                              })}
                            </span>
                          </div>
                          
                          {/* Clips Count */}
                          <div className="pt-1">
                            {item.clipsCount > 0 ? (
                              <span className="text-sm font-medium text-primary">
                                {item.clipsCount} clip
                                {item.clipsCount !== 1 ? "s" : ""} →
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">No clips yet</span>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <YouTubeVideoModal
        isOpen={isYouTubeModalOpen}
        onClose={handleCloseYouTubeModal}
        videoUrl={youtubeUrl}
      />
    </div>
  );
}
